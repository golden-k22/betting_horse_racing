import sys
import time

import pandas as pd
from datetime import datetime
from pytz import timezone as pytimezone
from LBW_betfair_api import place_order
from LBW_tab_analysis import requestAllRunnersDf, get_pl, get_win_percent_in_range, bet_eval_chart_cPl

WEEKDAYS=['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN']
def check_daily_lay_back(file_path):
    daily_layback = pd.read_excel(file_path, sheet_name="Lay Back & Win",
                                  skiprows=4)
    periodical_function(daily_layback)


def analysis_daily_betting_result(file_path):
    daily_layback = pd.read_excel(file_path, sheet_name="Lay Back & Win",
                                  skiprows=4)
    all_runners_df = requestAllRunnersDf(daily_layback)
    df_pl = get_pl(all_runners_df, 50, 0.8, 4, 'winOdds')
    # fav_runners_df = all_runners_df.loc[all_runners_df["Selected"] == "Selected"]
    # get_win_percent_in_range(fav_runners_df)
    bet_eval_chart_cPl(df_pl)


def periodical_function(daily_layback):
    # daily_layback_ori=daily_layback.copy()
    while True:
        FMT = '%H:%M:%S'
        current_time_str = datetime.now(pytimezone('australia/melbourne')).strftime(FMT)
        current_time = datetime.strptime(current_time_str, FMT)
        print("daily lay back for betting --- ", daily_layback)
        for d_index, layback in daily_layback.iterrows():
            scheduled_time_str = layback['TIME'].strftime(FMT)
            scheduled_time = datetime.strptime(scheduled_time_str, FMT)
            time_diff = scheduled_time - current_time
            # print("time difference", time_diff.total_seconds())

            if time_diff.total_seconds() > 0 and time_diff.total_seconds() < 130:
                track_name = layback['TRACK           '].strip()
                race_name = "R" + str(layback['RACE'])
                runner_name = layback['Unnamed: 5'].strip()
                bet_type = layback['BET']

                print("{}-{}-{}-{}".format(track_name, race_name, runner_name, bet_type))
                bet_result = place_order(track_name, race_name, runner_name, bet_type, 10)
                if bet_result is True:
                    daily_layback = daily_layback.drop(d_index)
            elif time_diff.total_seconds() < 0:
                daily_layback = daily_layback.drop(d_index)
        time.sleep(5)

if __name__ == '__main__':
    current_date_str = datetime.now(pytimezone('australia/melbourne')).strftime('%Y%m%d')
    current_date_weekday=datetime.now(pytimezone('australia/melbourne')).weekday()
    csv_file_path=current_date_str+'_'+WEEKDAYS[current_date_weekday]+'_Daily_Selection.xlsx'

    file_path = csv_file_path
    if len(sys.argv) == 2:
        if sys.argv[1] == "betting":
            check_daily_lay_back(file_path)
        elif sys.argv[1] == "analysis":
            analysis_daily_betting_result(file_path)
