import json
import time

import requests
from datetime import datetime, timedelta
from pytz import timezone as pytimezone
import pandas as pd
import numpy as np
import plotly.express as px

NUMBER_OF_POSITION = 4

STAKE_VAL = 50
BBR_VAL = 0.8
PAYS_TO = 4

TIME_BETWEEN_REQUESTS = 10
MEETING_FILTER = ["ROSEHILL", "CAULFIELD", "MORPHETTVILLE", "FLEMINGTON", "RANDWICK", "SUNSHINE" "COAST"]


def requestMeetings(url):
    isException = True
    meetings = []
    request_ctn = 0
    while isException:
        try:
            request_ctn += 1
            if request_ctn > 5:
                isException = False
            else:
                response = requests.request("GET", url, headers={'Content-Type': 'application/json'})
                meetings = response.json()['meetings']
                isException = False
        except Exception as e:
            print("Wait... Request again now in meetings: ")
            isException = True
            time.sleep(TIME_BETWEEN_REQUESTS)
    return meetings


def requestRunners(url):
    isException = True
    runners = []
    while isException:
        try:
            response = requests.request("GET", url, headers={'Content-Type': 'application/json'})
            runners = response.json()['runners']
            isException = False
        except Exception as e:
            print("Wait... Request again now in runners: ")
            isException = True
            time.sleep(TIME_BETWEEN_REQUESTS)
    return runners


def getWinRunner(meeting, race, selected_runners):
    runners = requestRunners(race['_links']['self'])

    cols = ['meetingName', 'meetingDate', 'venue', 'race_type', 'link', 'raceNumber', 'raceName', 'runnerNumber',
            'runnerName', 'winOdds', 'Selected', 'finishedPosition']
    runner_lst = []
    selected_runner_df = pd.DataFrame()
    for index, runner in enumerate(runners):
        runnerName = runner['runnerName']
        runnerNo = runner['runnerNumber']
        position = runner['finishingPosition']
        if "bettingStatus" in runner['fixedOdds'].keys():
            if runner['fixedOdds']['bettingStatus'] == "Winner" or runner['fixedOdds']['bettingStatus'] == "Loser" or \
                    runner['fixedOdds']['bettingStatus'] == "Placing":
                winOdds = runner['fixedOdds']['returnWin']
                runner_track = [meeting['meetingName'], meeting['meetingDate'], meeting['venueMnemonic'],
                                meeting['raceType'],
                                race['_links']['self'], race['raceNumber'], race['raceName'],
                                runnerNo, runnerName, winOdds, "", position]
                runner_lst.append(runner_track)

                for d_index, layback in selected_runners.iterrows():
                    if meeting['meetingName'] in layback['TRACK           '].strip() and str(layback['RACE']) == str(
                            race['raceNumber']) and str(layback['SELECTION']) == str(runner['runnerNumber']):
                        selected_df_temp_list = []
                        selected_df_temp_list.append(runner_track)
                        selected_runner_df = pd.DataFrame(selected_df_temp_list, columns=cols)
                        print("selected runners---meeting ---{}, race---{}".format(layback['TRACK           '].strip(),
                                                                                   str(layback['RACE'])))

    runners_df = pd.DataFrame(runner_lst, columns=cols)
    runners_df.loc[runners_df['finishedPosition'] == 0, 'finishedPosition'] = 10

    if (not selected_runner_df.empty):
        selected_runner_df.iloc[0, selected_runner_df.columns.get_loc('Selected')] = "Selected"

    runners_df = runners_df.sort_values(['raceName', 'finishedPosition'], ascending=[True, True]).groupby(
        'raceName').head(NUMBER_OF_POSITION)
    # runners_df.to_csv("fav_runner_df.csv", encoding='utf-8', index=False)
    result_df = pd.concat([selected_runner_df, runners_df], axis=0)
    return result_df


def requestAllRunnersDf(selected_runners):
    current_date_str = datetime.now(pytimezone('australia/melbourne')).strftime('%Y-%m-%d')
    # current_date_str = '2022-11-15'

    url = "https://api.beta.tab.com.au/v1/historical-results-service/SA/racing/{0}".format(current_date_str)
    meetings = requestMeetings(url)
    with open('aus_races.json', 'w') as outfile:
        json.dump(meetings, outfile, indent=4)
    cols = ['meetingName', 'meetingDate', 'venue', 'race_type', 'link', 'raceNumber', 'raceName', 'runnerNumber',
            'runnerName', 'winOdds', 'Selected', 'finishedPosition']
    runners_df = pd.DataFrame([], columns=cols)

    for index, meeting in enumerate(meetings):
        # if (meeting['raceType'] == "R") and (
        #         meeting['location'] in ['VIC', 'QLD', 'TAS', 'WA', 'SA', 'NT', 'ACT', 'NSW']) \
        #         and meeting['meetingName'] in MEETING_FILTER:
        if (meeting['raceType'] == "R") and (
                meeting['location'] in ['VIC', 'QLD', 'TAS', 'WA', 'SA', 'NT', 'ACT', 'NSW']):
            for r_index, race in enumerate(meeting['races']):

                if race['raceStatus'] == "Paying":
                    runners = getWinRunner(meeting, race, selected_runners)
                    runners_df = pd.concat([runners_df, runners], axis=0)

    runners_df.to_csv("fav_runner_df.csv", encoding='utf-8', index=False)
    print("=============================End {0}=============================".format(current_date_str))
    return runners_df


def get_win_percent_in_range(meeting_df):
    total_cnt = (meeting_df['Selected'] == 'Selected').sum()
    top1_win_cnt = (meeting_df['finishedPosition'] == 1).sum()
    top1_win_percent = format(100 * top1_win_cnt / total_cnt, ".2f")
    r1_cnt = ((meeting_df['winOdds'] >= 1.01) & (meeting_df['winOdds'] <= 1.5)).sum()
    top_r1_cnt = ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 1.01) & (
            meeting_df['winOdds'] <= 1.5)).sum()
    top_r1_percent = (format(100 * top_r1_cnt / r1_cnt, ".2f")) if r1_cnt > 0 else 0
    r2_cnt = ((meeting_df['winOdds'] >= 1.51) & (meeting_df['winOdds'] <= 2.0)).sum()
    top_r2_cnt = ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 1.51) & (
            meeting_df['winOdds'] <= 2.0)).sum()
    top_r2_percent = (format(100 * top_r2_cnt / r2_cnt, ".2f")) if r2_cnt > 0 else 0
    r3_cnt = ((meeting_df['winOdds'] >= 2.01) & (meeting_df['winOdds'] <= 2.5)).sum()
    top_r3_cnt = ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 2.01) & (
            meeting_df['winOdds'] <= 2.5)).sum()
    top_r3_percent = (format(100 * top_r3_cnt / r3_cnt, ".2f")) if r3_cnt > 0 else 0
    r4_cnt = ((meeting_df['winOdds'] >= 2.51) & (meeting_df['winOdds'] <= 3.0)).sum()
    top_r4_cnt = ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 2.51) & (
            meeting_df['winOdds'] <= 3.0)).sum()
    top_r4_percent = (format(100 * top_r4_cnt / r4_cnt, ".2f")) if r4_cnt > 0 else 0
    r5_cnt = ((meeting_df['winOdds'] >= 3.01) & (meeting_df['winOdds'] <= 3.5)).sum()
    top_r5_cnt = ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 3.01) & (
            meeting_df['winOdds'] <= 3.5)).sum()
    top_r5_percent = (format(100 * top_r5_cnt / r5_cnt, ".2f")) if r5_cnt > 0 else 0
    r6_cnt = ((meeting_df['winOdds'] >= 3.51) & (meeting_df['winOdds'] <= 4.0)).sum()
    top_r6_cnt = ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 3.51) & (
            meeting_df['winOdds'] <= 4.0)).sum()
    top_r6_percent = (format(100 * top_r6_cnt / r6_cnt, ".2f")) if r6_cnt > 0 else 0
    r7_cnt = ((meeting_df['winOdds'] >= 4.01) & (meeting_df['winOdds'] <= 4.5)).sum()
    top_r7_cnt = ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 4.01) & (
            meeting_df['winOdds'] <= 4.5)).sum()
    top_r7_percent = (format(100 * top_r7_cnt / r7_cnt, ".2f")) if r7_cnt > 0 else 0
    r8_cnt = ((meeting_df['winOdds'] >= 4.51) & (meeting_df['winOdds'] <= 5.0)).sum()
    top_r8_cnt = ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 4.51) & (
            meeting_df['winOdds'] <= 5.0)).sum()
    top_r8_percent = (format(100 * top_r8_cnt / r8_cnt, ".2f")) if r8_cnt > 0 else 0
    r9_cnt = ((meeting_df['winOdds'] >= 5.01)).sum()
    top_r9_cnt = ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 5.01)).sum()
    top_r9_percent = (format(100 * top_r9_cnt / r9_cnt, ".2f")) if r9_cnt > 0 else 0

    print("Total races : {0}, winners : {1}, {2} % ".format(total_cnt, top1_win_cnt, top1_win_percent))
    print("in range 1.01 ~ 1.5 : {0} Selected {1} winners {2} %".format(r1_cnt, top_r1_cnt, top_r1_percent))
    print("in range 1.51 ~ 2.0 : {0} Selected {1} winners {2} %".format(r2_cnt, top_r2_cnt, top_r2_percent))
    print("in range 2.01 ~ 2.5 : {0} Selected {1} winners {2} %".format(r3_cnt, top_r3_cnt, top_r3_percent))
    print("in range 2.51 ~ 3.0 : {0} Selected {1} winners {2} %".format(r4_cnt, top_r4_cnt, top_r4_percent))
    print("in range 3.01 ~ 3.5 : {0} Selected {1} winners {2} %".format(r5_cnt, top_r5_cnt, top_r5_percent))
    print("in range 3.51 ~ 4.0 : {0} Selected {1} winners {2} %".format(r6_cnt, top_r6_cnt, top_r6_percent))
    print("in range 4.01 ~ 4.5 : {0} Selected {1} winners {2} %".format(r7_cnt, top_r7_cnt, top_r7_percent))
    print("in range 4.51 ~ 5.0 : {0} Selected {1} winners {2} %".format(r8_cnt, top_r8_cnt, top_r8_percent))
    print("in range 5.01 ~     : {0} Selected {1} winners {2} %".format(r9_cnt, top_r9_cnt, top_r9_percent))


def get_win_percent(meeting_df):
    total_cnt = (meeting_df['Selected'] == 'Selected').sum()

    top_r1_percent = []
    top_r2_percent = []
    top_r3_percent = []
    top_r4_percent = []
    top_r5_percent = []
    top_r6_percent = []
    top_r7_percent = []
    top_r8_percent = []
    top_r9_percent = []
    top1_win_percent = 100 * (meeting_df['finishedPosition'] == 1).sum() / total_cnt
    top_r1_percent.append(format(100 * ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 1.01) & (
            meeting_df['winOdds'] <= 1.5)).sum() / total_cnt, ".2f"))
    top_r2_percent.append(format(100 * ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 1.51) & (
            meeting_df['winOdds'] <= 2.0)).sum() / total_cnt, ".2f"))
    top_r3_percent.append(format(100 * ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 2.01) & (
            meeting_df['winOdds'] <= 2.5)).sum() / total_cnt, ".2f"))
    top_r4_percent.append(format(100 * ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 2.51) & (
            meeting_df['winOdds'] <= 3.0)).sum() / total_cnt, ".2f"))
    top_r5_percent.append(format(100 * ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 3.01) & (
            meeting_df['winOdds'] <= 3.5)).sum() / total_cnt, ".2f"))
    top_r6_percent.append(format(100 * ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 3.51) & (
            meeting_df['winOdds'] <= 4.0)).sum() / total_cnt, ".2f"))
    top_r7_percent.append(format(100 * ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 4.01) & (
            meeting_df['winOdds'] <= 4.5)).sum() / total_cnt, ".2f"))
    top_r8_percent.append(format(100 * ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 4.51) & (
            meeting_df['winOdds'] <= 5.0)).sum() / total_cnt, ".2f"))
    top_r9_percent.append(
        format(100 * ((meeting_df['finishedPosition'] == 1) & (meeting_df['winOdds'] >= 5.01)).sum() / total_cnt,
               ".2f"))

    top2_win_percent = 100 * (meeting_df['finishedPosition'] <= 2).sum() / total_cnt
    top_r1_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 2) & (meeting_df['winOdds'] >= 1.01) & (
            meeting_df['winOdds'] <= 1.5)).sum() / total_cnt, ".2f"))
    top_r2_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 2) & (meeting_df['winOdds'] >= 1.51) & (
            meeting_df['winOdds'] <= 2.0)).sum() / total_cnt, ".2f"))
    top_r3_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 2) & (meeting_df['winOdds'] >= 2.01) & (
            meeting_df['winOdds'] <= 2.5)).sum() / total_cnt, ".2f"))
    top_r4_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 2) & (meeting_df['winOdds'] >= 2.51) & (
            meeting_df['winOdds'] <= 3.0)).sum() / total_cnt, ".2f"))
    top_r5_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 2) & (meeting_df['winOdds'] >= 3.01) & (
            meeting_df['winOdds'] <= 3.5)).sum() / total_cnt, ".2f"))
    top_r6_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 2) & (meeting_df['winOdds'] >= 3.51) & (
            meeting_df['winOdds'] <= 4.0)).sum() / total_cnt, ".2f"))
    top_r7_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 2) & (meeting_df['winOdds'] >= 4.01) & (
            meeting_df['winOdds'] <= 4.5)).sum() / total_cnt, ".2f"))
    top_r8_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 2) & (meeting_df['winOdds'] >= 4.51) & (
            meeting_df['winOdds'] <= 5.0)).sum() / total_cnt, ".2f"))
    top_r9_percent.append(
        format(100 * ((meeting_df['finishedPosition'] <= 2) & (meeting_df['winOdds'] >= 5.01)).sum() / total_cnt,
               ".2f"))

    top3_win_percent = 100 * (meeting_df['finishedPosition'] <= 3).sum() / total_cnt
    top_r1_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 3) & (meeting_df['winOdds'] >= 1.01) & (
            meeting_df['winOdds'] <= 1.5)).sum() / total_cnt, ".2f"))
    top_r2_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 3) & (meeting_df['winOdds'] >= 1.51) & (
            meeting_df['winOdds'] <= 2.0)).sum() / total_cnt, ".2f"))
    top_r3_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 3) & (meeting_df['winOdds'] >= 2.01) & (
            meeting_df['winOdds'] <= 2.5)).sum() / total_cnt, ".2f"))
    top_r4_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 3) & (meeting_df['winOdds'] >= 2.51) & (
            meeting_df['winOdds'] <= 3.0)).sum() / total_cnt, ".2f"))
    top_r5_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 3) & (meeting_df['winOdds'] >= 3.01) & (
            meeting_df['winOdds'] <= 3.5)).sum() / total_cnt, ".2f"))
    top_r6_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 3) & (meeting_df['winOdds'] >= 3.51) & (
            meeting_df['winOdds'] <= 4.0)).sum() / total_cnt, ".2f"))
    top_r7_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 3) & (meeting_df['winOdds'] >= 4.01) & (
            meeting_df['winOdds'] <= 4.5)).sum() / total_cnt, ".2f"))
    top_r8_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 3) & (meeting_df['winOdds'] >= 4.51) & (
            meeting_df['winOdds'] <= 5.0)).sum() / total_cnt, ".2f"))
    top_r9_percent.append(
        format(100 * ((meeting_df['finishedPosition'] <= 3) & (meeting_df['winOdds'] >= 5.01)).sum() / total_cnt,
               ".2f"))

    top4_win_percent = 100 * (meeting_df['finishedPosition'] <= 4).sum() / total_cnt
    top_r1_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 4) & (meeting_df['winOdds'] >= 1.01) & (
            meeting_df['winOdds'] <= 1.5)).sum() / total_cnt, ".2f"))
    top_r2_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 4) & (meeting_df['winOdds'] >= 1.51) & (
            meeting_df['winOdds'] <= 2.0)).sum() / total_cnt, ".2f"))
    top_r3_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 4) & (meeting_df['winOdds'] >= 2.01) & (
            meeting_df['winOdds'] <= 2.5)).sum() / total_cnt, ".2f"))
    top_r4_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 4) & (meeting_df['winOdds'] >= 2.51) & (
            meeting_df['winOdds'] <= 3.0)).sum() / total_cnt, ".2f"))
    top_r5_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 4) & (meeting_df['winOdds'] >= 3.01) & (
            meeting_df['winOdds'] <= 3.5)).sum() / total_cnt, ".2f"))
    top_r6_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 4) & (meeting_df['winOdds'] >= 3.51) & (
            meeting_df['winOdds'] <= 4.0)).sum() / total_cnt, ".2f"))
    top_r7_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 4) & (meeting_df['winOdds'] >= 4.01) & (
            meeting_df['winOdds'] <= 4.5)).sum() / total_cnt, ".2f"))
    top_r8_percent.append(format(100 * ((meeting_df['finishedPosition'] <= 4) & (meeting_df['winOdds'] >= 4.51) & (
            meeting_df['winOdds'] <= 5.0)).sum() / total_cnt, ".2f"))
    top_r9_percent.append(
        format(100 * ((meeting_df['finishedPosition'] <= 4) & (meeting_df['winOdds'] >= 5.01)).sum() / total_cnt,
               ".2f"))

    # Print the result
    print("Total races ".format(total_cnt))
    print("Favorite finished Top 1st {0} %".format(format(top1_win_percent, ".2f")))
    print("Favorite finished Top 2st {0} %".format(format(top2_win_percent, ".2f")))
    print("Favorite finished Top 3st {0} %".format(format(top3_win_percent, ".2f")))
    print("Favorite finished Top 4st {0} %".format(format(top4_win_percent, ".2f")))
    # Print detail analysis
    fav_analysis_df = pd.DataFrame({
        'Fav No': [1, 2, 3, 4],
        'Total': [format(top1_win_percent, ".2f"), format(top2_win_percent, ".2f"), format(top3_win_percent, ".2f"),
                  format(top4_win_percent, ".2f")],
        '1.01~': top_r1_percent,
        '1.51~': top_r2_percent,
        '2.01~': top_r3_percent,
        '2.51~': top_r4_percent,
        '3.01~': top_r5_percent,
        '3.51~': top_r6_percent,
        '4.01~': top_r7_percent,
        '4.51~': top_r8_percent,
        'Over 5.0': top_r9_percent
    })
    print(fav_analysis_df)


def get_pl(df, stake, bbr, pays_to, back_odds='winOdds', lay_odds='winOdds'):
    # df_fav = df.groupby('market_id')['winOdds']
    conditions = [(df['Selected'] == "Selected") & (df['finishedPosition'] == 1),
                  (df['Selected'] == "Selected") & (df['finishedPosition'] <= pays_to),
                  (df['Selected'] == "Selected") & (df['finishedPosition'] > pays_to),
                  (df['Selected'] != "Selected")]
    choices = [stake * df[back_odds], (stake * bbr) - stake, -stake, 0]

    df['win'] = np.select(conditions, choices)

    df.to_csv("df_pl.csv", encoding='utf-8')

    return (df)


def bet_eval_chart_cPl(d):
    d = (
        d
            .groupby(['meetingName', 'raceName'])
            .agg({'win': 'sum'})
    )

    d['market_number'] = np.arange(len(d))
    d['cNpl'] = d.win.cumsum()

    chart = px.line(d, x="market_number", y="cNpl", title='Cumulative Net Profit', template='simple_white')
    chart.show()

    return (chart)


if __name__ == '__main__':
    all_runners_df = requestAllRunnersDf()
    df_pl = get_pl(all_runners_df, STAKE_VAL, BBR_VAL, PAYS_TO, 'winOdds')
    fav_runners_df = all_runners_df.loc[all_runners_df["Selected"] == "Selected"]
    get_win_percent_in_range(fav_runners_df)
    bet_eval_chart_cPl(df_pl)
